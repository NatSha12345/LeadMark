
  # Create Landing Page

  This is a code bundle for Create Landing Page. The original project is available at https://www.figma.com/design/p7KOfEJFXKhghDXyqFOFCm/Create-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  